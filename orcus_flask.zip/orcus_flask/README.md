# Orcus — Flask

Pixel-oriented Flask implementation of the supplied Figma prototype.

## Run

```bash
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows:
# .venv\Scripts\activate

pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

## Notes

- The page is authored at the Figma canvas size of 1920×4919 px and uses the exact measurements/colors/text visible in node `194:5`.
- Figma-exported SVG assets are referenced from Figma's temporary MCP asset URLs so the implementation can be compared immediately against the source. Those URLs are temporary; for production, replace them with locally committed copies exported from the Figma file.
- The original design uses NT Somic and NexaText. The CSS requests those fonts first and falls back to Arial/system fonts if they are not installed locally. For true pixel identity, install/provide the exact font files and uncomment the @font-face declarations.
- FAQ rows are interactive and the contact form submits to `/contact`.
