from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.get("/")
def index():
    return render_template("index.html")

@app.post("/contact")
def contact():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip()
    message = (data.get("message") or "").strip()
    if not email or not message:
        return jsonify({"ok": False, "error": "Заполните Email и обращение."}), 400
    # Demo endpoint: replace with real mail/CRM integration.
    return jsonify({"ok": True, "message": "Заявка отправлена."})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
