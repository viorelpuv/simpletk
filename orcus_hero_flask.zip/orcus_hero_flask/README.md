# Orcus Hero — Flask

This stage intentionally contains only the Hero. Desktop geometry is copied from Figma node 209:108: 1920x1000 canvas, literal x/y coordinates, exact dimensions, font sizes, line heights, button geometry and shadows. Below 900px the layout switches to a separate responsive composition rather than scaling individual elements independently.

Figma SVG exports were requested for nodes 198:431, 206:8 and 209:105. Their temporary Figma URLs are listed in `FIGMA_ASSETS.txt`; replace the three placeholder SVG files with the downloaded bytes before deployment.

Run: `pip install -r requirements.txt && python app.py`
