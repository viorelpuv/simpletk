# Orcus — Flask, Figma-matched responsive build

This version rebuilds the supplied Figma node `194:5` using normal responsive layout rather than scaling a 1920px canvas. The desktop breakpoints preserve the Figma geometry while tablet/mobile layouts reflow naturally.

## Run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

### Included fixes
- restored the missing block immediately after the hero (Figma y=1044)
- corrected the case-grid geometry: 880px feature card + 430/430 top cards + 880px lower card
- corrected button centering and typography
- FAQ, contact form and mobile menu are interactive
- responsive breakpoints at 1200px and 760px; no desktop-canvas `transform: scale()` hack
- all Figma SVG references used by the design remain in the HTML; the asset URLs are temporary Figma URLs and should be exported locally for production
